
const YOUR_API_KEY = "AIzaSyDSO2i-iJiHZ9We7lBMu9hY8v5V68QdtZY"
export const API =
 "https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics&chart=mostPopular&maxResults=50&regionCode=IN&key=AIzaSyDSO2i-iJiHZ9We7lBMu9hY8v5V68QdtZY"

 export const YOUTUBE_SEARCH = "http://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q="

 export const LIVE_CHAT_COUNT = 25;

 export const YOUTUBE_SEARCH_RESULTS = "https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&q=iphone&regionCode=IN&key="